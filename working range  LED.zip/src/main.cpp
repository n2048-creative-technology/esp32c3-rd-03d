#include <Arduino.h>
#include "RadarSensor.h"

#ifndef LED_PIN
#define LED_PIN 8 // Default LED pin for ESP32-C3
#endif

#define MIN_DISTANCE_MM 600.0f
#define MAX_DISTANCE_MM 1500.0f

RadarSensor radar(GPIO_NUM_20,GPIO_NUM_21); // RX, TX pins on the ESP to sensor TX, RX pins

void setup() {
  Serial.begin(115200);
  radar.begin(256000);
  Serial.println("Radar Sensor Started");

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
}

float distance = 0.0f;

void loop() {
  if (radar.update()) {
    RadarTarget tgt = radar.getTarget();
    distance = tgt.distance;
    Serial.print("X (mm): "); Serial.println(tgt.x);
    Serial.print("Y (mm): "); Serial.println(tgt.y);
    Serial.print("Distance (mm): "); Serial.println(tgt.distance);
    Serial.print("Angle (degrees): "); Serial.println(tgt.angle);
    Serial.print("Speed (cm/s): "); Serial.println(tgt.speed);
    Serial.println("-------------------------");
  }

  // turn on led when target in range
  digitalWrite(LED_PIN, (distance > MIN_DISTANCE_MM && distance < MAX_DISTANCE_MM) ? LOW : HIGH);

  // Small cooperative delay to keep system responsive
  delay(1);
}
