#include <Arduino.h>
#include "RadarSensor.h"

#ifndef LED_PIN
#define LED_PIN 8 // Default LED pin for ESP32-C3
#endif

RadarSensor radar(GPIO_NUM_20,GPIO_NUM_21); // RX, TX pins on the ESP to sensor TX, RX pins

static bool led_state = false;
static unsigned long led_last_toggle = 0;

void setup() {
  Serial.begin(115200);
  radar.begin(256000);
  Serial.println("Radar Sensor Started");

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  led_state = false;
  led_last_toggle = millis();
}

void loop() {
  if (radar.update()) {
    RadarTarget tgt = radar.getTarget();
    Serial.print("X (mm): "); Serial.println(tgt.x);
    Serial.print("Y (mm): "); Serial.println(tgt.y);
    Serial.print("Distance (mm): "); Serial.println(tgt.distance);
    Serial.print("Angle (degrees): "); Serial.println(tgt.angle);
    Serial.print("Speed (cm/s): "); Serial.println(tgt.speed);
    Serial.println("-------------------------");
  }

  // Blink LED every 500 ms (non-blocking)
  if (millis() - led_last_toggle >= 500) {
    led_last_toggle = millis();
    led_state = !led_state;
    digitalWrite(LED_PIN, led_state ? HIGH : LOW);
  }

  // Small cooperative delay to keep system responsive
  delay(1);
}
